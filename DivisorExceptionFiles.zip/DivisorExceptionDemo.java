package Study;

public class DivisorExceptionDemo {
	public static void main(String[] args) {
		DivisorException divExcept = new DivisorException(); 

	}
}
